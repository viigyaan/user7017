x=float(input("Enter value of x:"))

y = 1/(x+(1/(x+(1/(x+(1/x))))))
print(y)